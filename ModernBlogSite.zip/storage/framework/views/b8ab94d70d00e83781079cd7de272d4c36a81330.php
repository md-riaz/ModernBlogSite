
<?php $__env->startSection('siteTitle'); ?>
Edit Post
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<ul class="buttons d_flex justify-content-center">
    <li><a href="<?php echo e(URL::to('category')); ?>"><button class="flat-btn">all category</button></a></li>
    <li><a href="<?php echo e(URL::to('category/create')); ?>"><button class="flat-btn">add category</button></a></li>
    <li><a href="<?php echo e(URL::to('post')); ?>"><button class="flat-btn">all posts</button></a></li>
    <li><a href="<?php echo e(URL::to('post/create')); ?>"><button class="flat-btn">write post</button></a></li>
</ul>
<hr>
<div class="container">
    <div class="write-post">
        <div class="post-comments">
            <h2 class="comments-title">Edit an existing post.</h2>
            <div class="comment-respond">
                <form action="<?php echo e(url('post/'.$post->id)); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="d_flex comment-double">
                        <div class="input-field">
                            <input type="text" name="title" value="<?php echo e($post->title); ?>" aria-required="true" required />
                        </div>
                        <div class="input-field">
                            <select name="category_id">
                                <option value="" disabled selected>Select a Category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php echo e($item->id==$post->category_id ? 'selected' : ''); ?>>
                                    <?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="input-field">
                        <input type="file" name="post_img">
                        <label for="">Current Image</label><br>
                        <img src="<?php echo e(asset('public/frontend/postimg/'.$post->post_img)); ?>" alt="" width="120">
                        <input type="hidden" name="old_img" value="<?php echo e($post->post_img); ?>">
                    </div>
                    <div class=" input-field">
                        <textarea name="details" aria-required="true" required><?php echo e($post->details); ?></textarea>
                    </div>

                    
                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                    

                    <p class="form-submit">
                        <input name="submit" type="submit" class="submit" value="Update Category" required />
                    </p>
                </form>
            </div>
            <!-- #respond -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ModernBlogSite\resources\views/post/edit.blade.php ENDPATH**/ ?>
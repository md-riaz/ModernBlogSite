
<?php $__env->startSection('siteTitle'); ?>
Admin Panel
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<ul class="buttons d_flex">
    <li><a href="<?php echo e(URL::to('category')); ?>"><button class="flat-btn">all category</button></a></li>
    <li><a href="<?php echo e(URL::to('category/create')); ?>"><button class="flat-btn">add category</button></a></li>
    <li><a href="<?php echo e(URL::to('post')); ?>"><button class="flat-btn">all posts</button></a></li>
    <li><a href="<?php echo e(URL::to('post/create')); ?>"><button class="flat-btn">write post</button></a></li>
</ul>
<hr>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ModernBlogSite\resources\views/main.blade.php ENDPATH**/ ?>
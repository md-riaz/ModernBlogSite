
<?php $__env->startSection('siteTitle'); ?>
Home
<?php $__env->stopSection(); ?>


<?php $__env->startSection('FeaturePost'); ?>
<!--   Feature Post Section -->
<section class="feature-posts">
    <div class="feature-posts_wrapper d_flex feature-post-slider owl-carousel owl-theme">

        <div class="feature-post d_flex item owl-lazy"
            data-src="<?php echo e(asset('public/frontend/img/feature_posts/feature_post_1.jpg')); ?>">
            <span class="overlay"></span>
            <div class="feature-post_content d_flex">
                <div class="categories d_flex">
                    <a href="#">beauty</a>
                    <a href="#">health</a>
                    <a href="#">lifestyle</a>
                </div>
                <a class="title">
                    from grapefruit to lemons to oranges, citrus does you good!
                </a>
                <div class="post_bottom d_flex">
                    <p class="date">june 14,2015</p>
                    <div class="comments d_flex">
                        <i class="fas fa-comment"></i>
                        <p>24</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="feature-post d_flex item owl-lazy"
            data-src="<?php echo e(asset('public/frontend/img/feature_posts/feature_post_2.jpg')); ?>">
            <span class="overlay"></span>
            <div class="feature-post_content d_flex">
                <div class="categories d_flex">
                    <a href="#">beauty</a>
                    <a href="#">health</a>
                    <a href="#">lifestyle</a>
                </div>
                <a class="title">
                    from grapefruit to lemons to oranges, citrus does you good!
                </a>
                <div class="post_bottom d_flex">
                    <p class="date">june 14,2015</p>
                    <div class="comments d_flex">
                        <i class="fas fa-comment"></i>
                        <p>24</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="feature-post d_flex item owl-lazy"
            data-src="<?php echo e(asset('public/frontend/img/feature_posts/feature_post_3.jpg')); ?>">
            <span class="overlay"></span>
            <div class="feature-post_content d_flex">
                <div class="categories d_flex">
                    <a href="#">beauty</a>
                    <a href="#">health</a>
                    <a href="#">lifestyle</a>
                </div>
                <a class="title">
                    from grapefruit to lemons to oranges, citrus does you good!
                </a>
                <div class="post_bottom d_flex">
                    <p class="date">june 14,2015</p>
                    <div class="comments d_flex">
                        <i class="fas fa-comment"></i>
                        <p>24</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="btn-prev"></div>
    <div class="btn-next"></div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!--   Main Post Section -->
<section class="post-list">

    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="posts">
        <div class="posts_contents_wrapper d_flex">
            <div class="posts_preview_img">
                <img src="<?php echo e($post->post_img); ?>" alt="preview_img">
            </div>
            <div class="posts_desc d_flex">
                <div class="posts_title">
                    <div class="categories d_flex">
                        <a href="#"><?php echo e($post->category->name); ?></a>
                        <a href="#">health</a>
                    </div>
                    <a class="title" href="<?php echo e(url('post/'. $post->id)); ?>">
                        <?php echo e($post->title); ?>

                    </a>
                    <div class="info d_flex">
                        <p class="date"><?php echo e($post->created_at->format('d F, Y')); ?></p>
                        <p class="author">by <a href="#"><?php echo e($post->user->name); ?></a></p>
                    </div>
                </div>
                <p class="text_contents">
                    <?php echo substr($post->details,0,132); ?>

                    <br>
                    <a class="read_more" href="<?php echo e(url('post/'. $post->id)); ?>">...</a>
                </p>
            </div>
        </div>
        <div class="post_buttons d_flex">
            <div class="comments d_flex">
                <i class="far fa-comment"></i>
                <p>24</p>
            </div>
            <div class="post_share">
                <span>Share</span>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-pinterest"></i></a>
                <a href="#"><i class="fab fa-facebook-f"></i></a>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if($posts instanceof \Illuminate\Pagination\LengthAwarePaginator): ?>)
    <nav class="pagination">
        <div class="page-links">
            <a class="prev page-numbers <?php echo e($posts->previousPageUrl()==null ? 'd-none' : ''); ?>"
                href="<?php echo e($posts->previousPageUrl()); ?>">previews</a>

            <?php for($i = 1; $i < $posts->lastPage()+1; $i++): ?>
                <a class="page-numbers <?php echo e($posts->currentPage() == $i ? 'current' : ''); ?>"
                    href=" <?php echo e($posts->url($i)); ?>"><?php echo e($i); ?></a>
                <?php endfor; ?>

                <a class="next page-numbers" <?php echo e($posts->previousPageUrl()==null ? 'd-none' : ''); ?>

                    href="<?php echo e($posts->nextPageUrl()); ?>">next</a>
        </div>

    </nav>
    <?php endif; ?>


</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ModernBlogSite\resources\views/index.blade.php ENDPATH**/ ?>

<?php $__env->startSection('siteTitle'); ?>
All Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<ul class="buttons d_flex justify-content-center">
    <li><a href="<?php echo e(URL::to('category')); ?>"><button class="flat-btn">all category</button></a></li>
    <li><a href="<?php echo e(URL::to('category/create')); ?>"><button class="flat-btn">add category</button></a></li>
    <li><a href="<?php echo e(URL::to('post')); ?>"><button class="flat-btn">all posts</button></a></li>
    <li><a href="<?php echo e(URL::to('post/create')); ?>"><button class="flat-btn">write post</button></a></li>
</ul>
<hr>

<table class="table table-responsive">
    <thead>
        <th>SL</th>
        <th>Category Name</th>
        <th>Slug</th>
        <th>Author</th>
        <th>Created at</th>
        <th>Action</th>
    </thead>
    <tbody>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($categories->firstItem() + $loop->index); ?></td>
            <td><?php echo e($row->name); ?></td>
            <td><?php echo e($row->slug); ?></td>
            <td><?php echo e($row->user->name); ?></td>
            <td><?php echo e($row->created_at->format('dS F, Y')); ?></td>
            <td>
                <a href="<?php echo e(url('category/'. $row->id.'/edit')); ?>" class="btn text-primary"><i
                        class="far fa-edit"></i></a>
                <a href="<?php echo e(url('category/'. $row->id)); ?>" class="btn text-secondary"><i class="far fa-eye"></i></a>

                <form action="" id="deleteForm" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn text-danger" id="delete"
                        data-action="<?php echo e(url('category/'. $row->id)); ?>"><i class="fas fa-trash"></i></button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php if($categories instanceof \Illuminate\Pagination\LengthAwarePaginator): ?>
<nav class="pagination">
    <div class="page-links">
        <a class="prev page-numbers <?php echo e($categories->previousPageUrl()==null ? 'd-none' : ''); ?>"
            href="<?php echo e($categories->previousPageUrl()); ?>">previews</a>

        <?php for($i = 1; $i < $categories->lastPage()+1; $i++): ?>
            <a class="page-numbers <?php echo e($categories->currentPage() == $i ? 'current' : ''); ?>"
                href=" <?php echo e($categories->url($i)); ?>"><?php echo e($i); ?></a>
            <?php endfor; ?>

            <a class="next page-numbers" <?php echo e($categories->previousPageUrl()==null ? 'd-none' : ''); ?>

                href="<?php echo e($categories->nextPageUrl()); ?>">next</a>
    </div>

</nav>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ModernBlogSite\resources\views/category/allcategory.blade.php ENDPATH**/ ?>
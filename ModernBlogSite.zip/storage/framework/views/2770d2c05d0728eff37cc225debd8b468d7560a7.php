
<?php $__env->startSection('siteTitle'); ?>
All Posts
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<ul class="buttons d_flex justify-content-center">
    <li><a href="<?php echo e(URL::to('category')); ?>"><button class="flat-btn">all category</button></a></li>
    <li><a href="<?php echo e(URL::to('category/create')); ?>"><button class="flat-btn">add category</button></a></li>
    <li><a href="<?php echo e(URL::to('post')); ?>"><button class="flat-btn">all posts</button></a></li>
    <li><a href="<?php echo e(URL::to('post/create')); ?>"><button class="flat-btn">write post</button></a></li>
</ul>
<hr>

<table class="table table-responsive">
    <thead>
        <th>SL</th>
        <th>Post Title</th>
        <th>Author</th>
        <th>Category</th>
        <th>Image</th>
        <th>Action</th>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <tr>
            <td><?php echo e($posts->firstItem() + $loop->index); ?></td>
            <td> <?php echo e(substr($row->title,0, 50)); ?>...</td>
            <td><?php echo e($row->user->name); ?></td>
            <td><?php echo e($row->category->name); ?></td>
            <td><img src="<?php echo e($row->post_img); ?>" alt="" width="80" height="50"></td>
            <td>
                <a href="<?php echo e(url('post/'. $row->id.'/edit')); ?>" class="btn table-primary"><i class="far fa-edit"></i></a>
                <a href="<?php echo e(url('post/'. $row->id)); ?>" class="btn text-secondary"><i class="far fa-eye"></i></a>

                <form action="" id="deleteForm" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn text-danger" id="delete"
                        data-action="<?php echo e(url('post/'. $row->id)); ?>"><i class="fas fa-trash"></i></button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="10">No data to show</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>

<?php if($posts instanceof \Illuminate\Pagination\LengthAwarePaginator): ?>
<nav class="pagination">
    <div class="page-links">
        <a class="prev page-numbers <?php echo e($posts->previousPageUrl()==null ? 'd-none' : ''); ?>"
            href="<?php echo e($posts->previousPageUrl()); ?>">previews</a>

        <?php for($i = 1; $i < $posts->lastPage()+1; $i++): ?>
            <a class="page-numbers <?php echo e($posts->currentPage() == $i ? 'current' : ''); ?>"
                href=" <?php echo e($posts->url($i)); ?>"><?php echo e($i); ?></a>
            <?php endfor; ?>

            <a class="next page-numbers" <?php echo e($posts->previousPageUrl()==null ? 'd-none' : ''); ?>

                href="<?php echo e($posts->nextPageUrl()); ?>">next</a>
    </div>

</nav>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ModernBlogSite\resources\views/post/all.blade.php ENDPATH**/ ?>
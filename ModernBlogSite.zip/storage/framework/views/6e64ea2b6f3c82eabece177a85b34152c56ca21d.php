
<?php $__env->startSection('siteTitle'); ?>
Write Post
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<ul class="buttons d_flex justify-content-center">
    <li><a href="<?php echo e(URL::to('category')); ?>"><button class="flat-btn">all category</button></a></li>
    <li><a href="<?php echo e(URL::to('category/create')); ?>"><button class="flat-btn">add category</button></a></li>
    <li><a href="<?php echo e(URL::to('post')); ?>"><button class="flat-btn">all posts</button></a></li>
    <li><a href="<?php echo e(URL::to('post/create')); ?>"><button class="flat-btn">write post</button></a></li>
</ul>
<hr>
<div class="container">
    <div class="write-post">
        <div class="post-comments">
            <h2 class="comments-title">Write a new post here.</h2>
            <div class="comment-respond">
                <form action="<?php echo e(url('post')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="d_flex comment-double">
                        <div class="input-field">
                            <input type="text" name="title" placeholder="Post Title *" aria-required="true" required />
                        </div>
                        <div class="input-field">
                            <select name="category_id">
                                <option value="" disabled selected>Select a Category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="input-field">
                        <input type="file" name="post_img">
                    </div>
                    <div class="input-field">
                        <textarea name="details" placeholder="Post Details *" aria-required="true" required></textarea>
                    </div>
                    
                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                    
                    <p class="form-submit">
                        <input name="submit" type="submit" class="submit" value="Submit your post" required />
                    </p>
                </form>
            </div>
            <!-- #respond -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ModernBlogSite\resources\views/post/write.blade.php ENDPATH**/ ?>